from .auth import UserToken as UserToken, UserTokenCollection as UserTokenCollection
from .constants import HTTP_CONNECT_TIMEOUT as HTTP_CONNECT_TIMEOUT
from .http_transport import install_connection_policy as install_connection_policy
from .server_response import ServerResponseCallback as ServerResponseCallback, install_logfire_response_hook as install_logfire_response_hook
from .utils import UnexpectedResponse as UnexpectedResponse
from _typeshed import Incomplete
from datetime import datetime
from logfire.exceptions import LogfireConfigError as LogfireConfigError
from logfire.version import VERSION as VERSION
from typing import Any
from typing_extensions import Self

UA_HEADER: Incomplete

class ProjectAlreadyExists(Exception): ...

class InvalidProjectName(Exception):
    reason: Incomplete
    def __init__(self, reason: str, /) -> None: ...

class LogfireClient:
    """A Logfire HTTP client to interact with the API.

    Args:
        user_token: The user token to use when authenticating against the API.
        server_response_hook: Optional override for the API response hook (see
            `AdvancedOptions.server_response_hook`).
    """
    base_url: Incomplete
    def __init__(self, user_token: UserToken, server_response_hook: ServerResponseCallback | None = None) -> None: ...
    @classmethod
    def from_url(cls, base_url: str | None, server_response_hook: ServerResponseCallback | None = None) -> Self:
        """Create a client from the provided base URL.

        Args:
            base_url: The base URL to use when looking for a user token. If `None`, will prompt
                the user into selecting a token from the token collection (or, if only one available,
                use it directly). The token collection will be created from the `~/.logfire/default.toml`
                file (or an empty one if no such file exists).
            server_response_hook: Optional override for the API response hook (see
                `AdvancedOptions.server_response_hook`).
        """
    def get_user_organizations(self) -> list[dict[str, Any]]:
        """Get the organizations of the logged-in user."""
    def get_user_information(self) -> dict[str, Any]:
        """Get information about the logged-in user."""
    def get_user_projects(self) -> list[dict[str, Any]]:
        """Get the projects of the logged-in user."""
    def create_new_project(self, organization: str, project_name: str):
        """Create a new project.

        Args:
            organization: The organization that should hold the new project.
            project_name: The name of the project to be created.

        Returns:
            The newly created project.
        """
    def create_write_token(self, organization: str, project_name: str) -> dict[str, Any]:
        """Create a write token for the given project in the given organization."""
    def create_read_token(self, organization: str, project_name: str, expires_at: datetime | None = None) -> dict[str, Any]:
        """Create a read token for the given project in the given organization.

        `expires_at` bounds how long the token stays valid. The CLI has no way to revoke
        one, so a token it stores on disk gets an expiry; a token it prints for the caller
        to place somewhere else does not, because we do not know what it was used for.
        """
    def get_prompt(self, organization: str, project_name: str, issue: str) -> dict[str, Any]:
        """Get a prompt to be used with your favorite LLM."""
